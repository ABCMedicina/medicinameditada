
<img class="w-20 rounded-full mt-5" src="{{ asset('storage/images/logo.jpg') }}" alt="Logo">
