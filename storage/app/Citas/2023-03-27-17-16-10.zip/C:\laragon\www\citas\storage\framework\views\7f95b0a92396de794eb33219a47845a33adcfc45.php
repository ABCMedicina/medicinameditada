 

<?php $__env->startSection('title', $procedimiento->nombre); ?>

<?php $__env->startSection('content'); ?>


    <div class="hero min-h-screen bg-base-200" >


      <div class="hero-content flex-col lg:flex-row" style="margin-left:100px; margin-right:100px;">
        <img class="max-w-sm rounded-lg shadow-2xl procedimiento-img" src="<?php echo e(asset('storage/images/procedimientos/proced'.$procedimiento->id.'.jpg')); ?>" alt="Logo">
        
        <div>
          <br>
        <h1 class="text-5xl font-bold" align="center"><?php echo e($procedimiento->nombre); ?></h1>

        <p class="py-6"><?php echo nl2br(e($procedimiento->descripcion)); ?></p>
        <button id="boton" class="btn btn-primary">Solicitar cita</button>
        </div>
      </div>
    </div>

    <br>
    <style>
      .procedimiento-img {
  max-width: 450px;
  max-height: 400px;
}
#boton {
  display: block;
  margin: 0 auto; 
  text-align: center;
}


    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\citas\resources\views/ver_procedimiento.blade.php ENDPATH**/ ?>