<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Atender cita')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
   
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
            <div class="flex justify-end">
    <button onclick="goBack()" class="btn mt-4 mr-5 btn-xs btn-primary">Regresar</button>
    </div>
                <div class="p-6 text-gray-900 dark:text-gray-100">
                  
                
                <div class="flex flex-col" id="printableArea">
                    

                     <div class="flex space-x-4">

                        <p> <span class="font-semibold">Paciente:</span> <?php echo e($cita->paciente->nombres. ' ' . $cita->paciente->apellidos); ?></p>
                        <div class="divider"></div>                     
                        <p> <span class="font-semibold">Documento:</span> <?php echo e($cita->paciente->documento); ?></p>
                        <p> <span class="font-semibold">Edad:</span> <?php echo e($cita->paciente->edad); ?> años</p>
                        <p> <span class="font-semibold">Teléfono:</span> <?php echo e($cita->paciente->telefono); ?></p>

                    </div>    
                    
                    <div class="flex space-x-4">
                        <p> <span class="font-semibold">Fecha:</span> <?php echo e($cita->agenda->fecha); ?></p>
                        <p> <span class="font-semibold">Hora:</span> <?php echo e($cita->agenda->hora); ?></p>
                        <p> <span class="font-semibold">Médico:</span> <?php echo e($cita->agenda->medico->name); ?></p>
                        <p> <span class="font-semibold">Procedimiento:</span> <?php echo e($cita->agenda->procedimiento->nombre); ?></p>
                        <p> <span class="font-semibold">Tipo de atención:</span> <?php echo e($cita->agenda->tipo); ?></p>

                    </div>

                    <div class="mt-10">
                        <p> <span class="font-bold">Observación:</span></p>
                        <textarea style="resize:none; border: 1px solid gray; border-radius: 10px;" disabled name="" id="" cols="110" rows="5"> <?php echo e($cita->observacion); ?></textarea>
                        
                    </div>

                    <div class="mt-5">
                        <p><span class="font-bold">Diagnóstico:</span></p>
                        <textarea style="resize:none; border: 1px solid gray; border-radius: 10px;" disabled name="" id="" cols="110" rows="5">  <?php echo e($cita->diagnostico); ?></textarea>

                    </div>

                    <div class="mt-5"><p><span class="font-bold">Medicamento:</span></p>
                    <textarea style="resize:none; border: 1px solid gray; border-radius: 10px;" disabled name="" id="" cols="110" rows="5">  <?php echo e($cita->medicamento); ?></textarea>

                    </div>
                    
                    </div>
                </div>
                   
                <div class="flex justify-center">
                    <button onclick="printDiv('printableArea')" class="m-5 btn btn-sm btn-primary">Imprimir</button>
                </div>

            <script>
                function printDiv(divName) {
                    var printContents = document.getElementById(divName).innerHTML;
                    var originalContents = document.body.innerHTML;
                    document.body.innerHTML = printContents;
                    window.print();
                    document.body.innerHTML = originalContents;
                }
                
                function goBack() {
                                    window.history.back();
                                }

                </script>
                        </div>
        </div>
    </div>
   
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\citas\resources\views/citas/show.blade.php ENDPATH**/ ?>