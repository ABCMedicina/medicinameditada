<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight" >
            <?php echo e(__('Lista de procedimientos')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8" >
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg" >
                <div class="p-6 pl-11 text-gray-900 dark:text-gray-100">
                    
                    
                    <div class="flex justify-end mb-5">
                        <a href="<?php echo e(route('procedimientos.create')); ?>" class="btn btn-outline btn-primary rounded-full">Crear Procedimiento</a>
                    </div>

                        <div class="grid grid-cols-4 gap-3" >
                        <?php $__currentLoopData = $procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card w-56 bg-base-100 shadow-xl mt-5 border" >
                            <figure>
                                <img class="mt-3 pl-3 pr-3 shadow-xl" style="height:290px; border-radius:13px;" src="<?php echo e(asset('storage/images/procedimientos/proced'.$procedimiento->id.'.jpg')); ?>" alt="Foto" />

                            </figure>
                            <div class="card-body">
                                <?php if($procedimiento->activo): ?>
                                    <span class="badge badge-success">Activo</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Inactivo</span>
                                <?php endif; ?>
                              <h2 class="card-title"><?php echo e($procedimiento->nombre); ?></h2>
                              <p><?php echo e(Str::limit($procedimiento->descripcion,50)); ?></p>
                              <div class="card-actions justify-end">
                                <a href="<?php echo e(route('procedimientos.edit', $procedimiento)); ?>" class="btn btn-xs btn-color">
                                  Editar
                                </a>
                                <?php if($procedimiento->agendas->count()==0): ?>
                                    <form action="<?php echo e(route('procedimientos.destroy', $procedimiento)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-xs btn-error">
                                        Eliminar
                                    </button>
                                    </form>
                                <?php endif; ?>
                              </div>
                            </div>
                          </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

            </div>
        </div>
    </div>
    
    <script>
        // alerta de eliminación de procedimiento
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                if (!confirm('¿Estás seguro de eliminar este procedimiento?')) {
                    e.preventDefault();
                }
            })
        })
    </script>

    <style>
        .btn-color {
    background-color: #25aff3;
    color: white;
    }

    </style>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\citas\resources\views/admin/procedimientos/index.blade.php ENDPATH**/ ?>