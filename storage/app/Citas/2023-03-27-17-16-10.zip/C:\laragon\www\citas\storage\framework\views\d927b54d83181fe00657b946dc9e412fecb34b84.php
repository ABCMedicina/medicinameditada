<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Agendar Cita')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
                        
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="flex p-6 text-gray-900 dark:text-gray-100 justify-center">
                    <div class="shadow-xl p-10 w-full">

                        <?php if($citas->count() > 0): ?>
                            <div class="grid grid-cols-3 gap-3">
                                    <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card w-72 bg-base-100 shadow-xl mt-5 border">
                                        <figure>
                                            <img class="mt-3 rounded-full" src="https://source.unsplash.com/random/200x200/?face&procedimiento=<?php echo e($cita->id); ?>" alt="Foto" />
                                        </figure>
                                        <div class="card-body">
                                        <h2 class="card-title">Md. <?php echo e($cita->medico->nombres . ' ' . $cita->medico->apellidos); ?></h2>
                                        <p><span class="font-semibold">Especialidad: </span> <?php echo e($cita->procedimiento->nombre); ?></p>
                                        <p><span class="font-semibold">Fecha: </span><?php echo e($cita->fecha); ?></p>
                                        <p><span class="font-semibold">Hora: </span><?php echo e($cita->hora); ?></p>
                                        <div class="card-actions justify-end">
                                            <form method="POST" action="<?php echo e(route('citas.store')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="agenda_id" value="<?php echo e($cita->id); ?>">
                                                <button type="submit" class="btn btn-primary" onclick="this.disabled=true;  this.innerHTML='Agendando...'; this.form.submit();" >Agendar</button>
                                            </form>
                                        </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="alert alert-info shadow-lg">
                                <div>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="stroke-current flex-shrink-0 w-6 h-6"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                                    <span>No existen citas disponibles para esta fecha y procedimiento.</span>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\citas\resources\views/citas/disponibles.blade.php ENDPATH**/ ?>