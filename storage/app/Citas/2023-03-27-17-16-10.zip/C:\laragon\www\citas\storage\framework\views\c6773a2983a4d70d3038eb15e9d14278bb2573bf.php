
<img class="w-20 rounded-full mt-5" src="<?php echo e(asset('storage/images/logo.jpg')); ?>" alt="Logo">
<?php /**PATH C:\laragon\www\citas\resources\views/components/application-logo.blade.php ENDPATH**/ ?>