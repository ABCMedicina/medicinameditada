<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Atender cita')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="mt-5">
                        
                        <div class="flex space-x-4">
                            <p> <span class="font-semibold">Paciente:</span> <?php echo e($cita->paciente->nombres. ' ' . $cita->paciente->apellidos); ?></p>
                            <p> <span class="font-semibold">Documento:</span> <?php echo e($cita->paciente->documento); ?></p>
                            <p> <span class="font-semibold">Edad:</span> <?php echo e($cita->paciente->edad); ?> años</p>
                            <p> <span class="font-semibold">Teléfono:</span> <?php echo e($cita->paciente->telefono); ?></p>
                        </div>
                        
                        <div class="flex space-x-4">
                            <p> <span class="font-semibold">Fecha:</span> <?php echo e($cita->agenda->fecha); ?></p>
                            <p> <span class="font-semibold">Hora:</span> <?php echo e($cita->agenda->hora); ?></p>
                            <p> <span class="font-semibold">Médico:</span> <?php echo e($cita->agenda->medico->name); ?></p>
                            <p> <span class="font-semibold">Procedimiento:</span> <?php echo e($cita->agenda->procedimiento->nombre); ?></p>
                            <p> <span class="font-semibold">Tipo de atención:</span> <?php echo e($cita->agenda->tipo); ?></p>
                        </div>
                        
                        <div>
                            <form class="flex flex-col mt-5 w-3/4" action="<?php echo e(route('citas.registra',$cita->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <label class="font-bold mt-5" for="observacion">Observación</label>
                                <textarea class="textarea textarea-bordered" name="observacion" id="observacion" cols="30" rows="5"><?php echo e($cita->observacion); ?></textarea>
                                
                                <label class="font-bold mt-5" for="diagnostico">Diagnóstico</label>
                                <textarea class="textarea textarea-bordered" name="diagnostico" id="diagnostico" cols="30" rows="5"><?php echo e($cita->diagnostico); ?></textarea>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('diagnostico'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('diagnostico')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                <label class="font-bold mt-5" for="medicamento">Medicamento</label>
                                <textarea class="textarea textarea-bordered" name="medicamento" id="medicamento" cols="30" rows="5"><?php echo e($cita->medicamento); ?></textarea>
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('medicamento'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('medicamento')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                <div class="flex justify-end space-x-3 mt-5">
                                    <button class="btn btn-primary btn-sm mr-5" type="submit">Guardar</button>
                                    <a href="<?php echo e(route('citas.agenda_dia')); ?>" class="btn btn-sm btn-outline btn-primary">
                                        Cancelar
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\citas\resources\views/citas/atender.blade.php ENDPATH**/ ?>