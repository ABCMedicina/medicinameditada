@extends('layouts.main') 

@section('title', $procedimiento->nombre)

@section('content')


    <div class="hero min-h-screen bg-base-200" >


      <div class="hero-content flex-col lg:flex-row" style="margin-left:100px; margin-right:100px;">
        <img class="max-w-sm rounded-lg shadow-2xl procedimiento-img" src="{{asset('storage/images/procedimientos/proced'.$procedimiento->id.'.jpg') }}" alt="Logo">
        
        <div>
          <br>
        <h1 class="text-5xl font-bold" align="center">{{ $procedimiento->nombre }}</h1>

        <p class="py-6">{!! nl2br(e($procedimiento->descripcion)) !!}</p>
        <button id="boton" class="btn btn-primary">Solicitar cita</button>
        </div>
      </div>
    </div>

    <br>
    <style>
      .procedimiento-img {
  max-width: 450px;
  max-height: 400px;
}
#boton {
  display: block;
  margin: 0 auto; 
  text-align: center;
}


    </style>
@endsection
